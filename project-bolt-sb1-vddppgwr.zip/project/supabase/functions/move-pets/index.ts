import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

Deno.serve(async (req: Request) => {
  try {
    if (req.method === "OPTIONS") {
      return new Response(null, {
        status: 200,
        headers: corsHeaders,
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Missing Supabase environment variables');
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get pets that need new movement targets
    const { data: pets, error: fetchError } = await supabase
      .from("pets")
      .select("*")
      .eq("is_dead", false)
      .lt("next_move_at", new Date().toISOString());

    if (fetchError) throw fetchError;

    if (!pets || pets.length === 0) {
      return new Response(
        JSON.stringify({ message: "No pets need movement updates" }),
        {
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders,
          },
        }
      );
    }

    // Fixed field dimensions (larger world)
    const MAP_WIDTH = 1920;
    const MAP_HEIGHT = 1080;
    const MIN_STEP = 50;
    const MAX_STEP = 150;
    const LONG_RANGE_CHANCE = 0.2;

    // Update each pet with new movement target
    for (const pet of pets) {
      let newX, newY, distance;

      // 20% chance for long-range movement (full map)
      if (Math.random() < LONG_RANGE_CHANCE) {
        newX = Math.random() * (MAP_WIDTH - 100) + 50; // 50px margin
        newY = Math.random() * (MAP_HEIGHT - 100) + 50;
      } else {
        // 80% chance for local wandering
        do {
          const dx = (Math.random() - 0.5) * 2 * MAX_STEP;
          const dy = (Math.random() - 0.5) * 2 * MAX_STEP;
          newX = Math.max(50, Math.min(MAP_WIDTH - 50, pet.x + dx));
          newY = Math.max(50, Math.min(MAP_HEIGHT - 50, pet.y + dy));
          distance = Math.hypot(newX - pet.x, newY - pet.y);
        } while (distance < MIN_STEP);
      }

      // Random wait time: 0.8-5 seconds
      const waitTime = 800 + Math.random() * 4200;
      const nextMoveAt = new Date(Date.now() + waitTime);

      const { error: updateError } = await supabase
        .from("pets")
        .update({
          target_x: Math.round(newX),
          target_y: Math.round(newY),
          next_move_at: nextMoveAt.toISOString(),
        })
        .eq("id", pet.id);

      if (updateError) {
        console.error(`Error updating pet ${pet.id}:`, updateError);
      }
    }

    return new Response(
      JSON.stringify({ 
        message: `Updated movement for ${pets.length} pets`,
        updated_count: pets.length 
      }),
      {
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );

  } catch (error) {
    console.error('Error in move-pets function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  }
});