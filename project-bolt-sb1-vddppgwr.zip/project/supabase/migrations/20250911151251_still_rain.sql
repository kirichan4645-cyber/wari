/*
  # Add movement synchronization fields

  1. New Columns
    - `next_move_at` (timestamptz) - When the pet should pick a new target
    - Updated existing `target_x`, `target_y` to be server-controlled

  2. Purpose
    - Enable server-side movement coordination
    - Maintain smooth client-side interpolation
    - Synchronize movement timing across all clients
*/

-- Add movement timing column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'pets' AND column_name = 'next_move_at'
  ) THEN
    ALTER TABLE pets ADD COLUMN next_move_at timestamptz DEFAULT now();
  END IF;
END $$;

-- Initialize next_move_at for existing pets with random delays
UPDATE pets 
SET next_move_at = now() + (random() * interval '5 seconds')
WHERE next_move_at IS NULL;