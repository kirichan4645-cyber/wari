/*
  # Add missing columns to pets table

  1. New Columns
    - `x` (integer, default 0) - X coordinate for pet position on map
    - `y` (integer, default 0) - Y coordinate for pet position on map
    - `updated_at` (timestamp, default now()) - Last update timestamp

  2. Updates
    - Add columns that were missing from the original schema
    - Set appropriate default values for existing records
*/

-- Add missing coordinate columns
ALTER TABLE pets ADD COLUMN IF NOT EXISTS x integer DEFAULT 0;
ALTER TABLE pets ADD COLUMN IF NOT EXISTS y integer DEFAULT 0;

-- Add missing updated_at column
ALTER TABLE pets ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

-- Update existing records to have random positions
UPDATE pets 
SET 
  x = FLOOR(RANDOM() * 700 + 50)::integer,
  y = FLOOR(RANDOM() * 500 + 50)::integer,
  updated_at = now()
WHERE x = 0 AND y = 0;