/*
  # Add Target Coordinates for Random Walk AI

  1. New Columns
    - `target_x` (integer) - Target X coordinate for smooth movement
    - `target_y` (integer) - Target Y coordinate for smooth movement
  
  2. Updates
    - Set initial target coordinates for existing pets
    - Add default values for new pets
*/

-- Add target coordinate columns
ALTER TABLE pets ADD COLUMN IF NOT EXISTS target_x integer DEFAULT 0;
ALTER TABLE pets ADD COLUMN IF NOT EXISTS target_y integer DEFAULT 0;

-- Set initial target coordinates for existing pets (random positions)
UPDATE pets 
SET 
  target_x = CASE 
    WHEN target_x = 0 THEN floor(random() * 1200 + 50)::integer
    ELSE target_x 
  END,
  target_y = CASE 
    WHEN target_y = 0 THEN floor(random() * 800 + 50)::integer  
    ELSE target_y
  END
WHERE is_dead = false;