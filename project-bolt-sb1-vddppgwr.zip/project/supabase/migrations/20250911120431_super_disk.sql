/*
  # Create pets table for pumpっち Web3 virtual pet game

  1. New Tables
    - `pets`
      - `id` (uuid, primary key)
      - `owner_id` (text, wallet address)
      - `name` (text, default: "pumpっち")
      - `hunger` (integer, 0-100)
      - `love` (integer, 0-100) 
      - `health` (integer, 0-100)
      - `x` (integer, position on map)
      - `y` (integer, position on map)
      - `is_dead` (boolean, default false)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `pets` table
    - Add policies for users to manage their own pets
    - Add policy for reading all alive pets (for map display)
*/

CREATE TABLE IF NOT EXISTS pets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id text NOT NULL,
  name text DEFAULT 'pumpっち',
  hunger integer DEFAULT 100 CHECK (hunger >= 0 AND hunger <= 100),
  love integer DEFAULT 100 CHECK (love >= 0 AND love <= 100),
  health integer DEFAULT 100 CHECK (health >= 0 AND health <= 100),
  x integer DEFAULT floor(random() * 800)::integer,
  y integer DEFAULT floor(random() * 600)::integer,
  is_dead boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE pets ENABLE ROW LEVEL SECURITY;

-- Policy for users to read all alive pets (for map display)
CREATE POLICY "Anyone can read alive pets"
  ON pets
  FOR SELECT
  USING (is_dead = false);

-- Policy for authenticated users to manage their own pets
CREATE POLICY "Users can manage own pets"
  ON pets
  FOR ALL
  USING (owner_id = current_setting('request.jwt.claims', true)::json->>'sub');

-- Policy for anonymous users to manage pets by owner_id (for Web3 wallets)
CREATE POLICY "Anonymous users can manage pets by owner_id"
  ON pets
  FOR ALL
  TO anon
  USING (true);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger to automatically update updated_at
CREATE TRIGGER update_pets_updated_at
  BEFORE UPDATE ON pets
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();