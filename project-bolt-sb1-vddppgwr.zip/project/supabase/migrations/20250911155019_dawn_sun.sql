/*
  # Update coordinate columns to support floating point values

  1. Changes
    - Change `x` column from integer to double precision
    - Change `y` column from integer to double precision  
    - Change `target_x` column from integer to double precision
    - Change `target_y` column from integer to double precision

  2. Reason
    - Support normalized coordinates (0.0 to 1.0) for responsive field system
    - Allows pets to be positioned using percentage-based coordinates
    - Enables smooth movement and proper scaling across different screen sizes
*/

ALTER TABLE pets 
  ALTER COLUMN x TYPE double precision USING x::double precision,
  ALTER COLUMN y TYPE double precision USING y::double precision,
  ALTER COLUMN target_x TYPE double precision USING target_x::double precision,
  ALTER COLUMN target_y TYPE double precision USING target_y::double precision;