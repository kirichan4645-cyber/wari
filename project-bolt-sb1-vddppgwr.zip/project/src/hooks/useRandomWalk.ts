// This hook is no longer needed as movement is now handled client-side
// Individual pet AI with local movement logic
export const useRandomWalk = () => {
  // Movement is now handled in PetMap component with individual pet AI
  return null;
};