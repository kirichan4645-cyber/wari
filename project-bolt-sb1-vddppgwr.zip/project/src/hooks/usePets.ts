import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Pet } from '../types/pet';

export const usePets = (ownerWallet?: string) => {
  const [pets, setPets] = useState<Pet[]>([]);
  const [userPet, setUserPet] = useState<Pet | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch all alive pets for the map
  const fetchAllPets = async () => {
    try {
      const { data, error } = await supabase
        .from('pets')
        .select('*')
        .eq('is_dead', false);

      if (error) throw error;
      setPets(data || []);
    } catch (err) {
      console.error('Error fetching pets:', err);
      setError('Failed to fetch pets');
    }
  };

  // Fetch user's specific pet
  const fetchUserPet = async (wallet: string) => {
    try {
      const { data, error } = await supabase
        .from('pets')
        .select('*')
        .eq('owner_id', wallet)
        .eq('is_dead', false)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned"
        throw error;
      }
      
      setUserPet(data || null);
    } catch (err) {
      console.error('Error fetching user pet:', err);
      setError('Failed to fetch user pet');
    }
  };

  // Create a new pet for the user
  const createPet = async (wallet: string, customName?: string) => {
    try {
      const newPet = {
        owner_id: wallet,
        name: customName || 'pumpっち',
        hunger: 100,
        love: 100,
        health: 100,
        sleep: 100,
        poop: 0,
        stage: 'egg',
        x: Math.random() * 0.8 + 0.1, // 10-90% of screen width
        y: Math.random() * 0.8 + 0.1, // 10-90% of screen height
        target_x: Math.random() * 0.8 + 0.1,
        target_y: Math.random() * 0.8 + 0.1,
        is_dead: false,
      };

      const { data, error } = await supabase
        .from('pets')
        .insert(newPet)
        .select()
        .single();

      if (error) throw error;
      
      setUserPet(data);
      await fetchAllPets(); // Refresh all pets
      return data;
    } catch (err) {
      console.error('Error creating pet:', err);
      setError('Failed to create pet');
      return null;
    }
  };

  // Create pet with custom name
  const createPetWithName = async (wallet: string, petName: string) => {
    return await createPet(wallet, petName);
  };

  // Update pet stats
  const updatePetStats = async (petId: string, stats: Partial<{ hunger: number; love: number; health: number; sleep: number; poop: number }>) => {
    try {
      const { data, error } = await supabase
        .from('pets')
        .update({
          ...stats,
          last_updated: new Date().toISOString(),
          // Mark as dead if hunger reaches 0
          is_dead: stats.hunger === 0 || undefined,
        })
        .eq('id', petId)
        .select()
        .single();

      if (error) throw error;

      setUserPet(data);
      await fetchAllPets(); // Refresh all pets
      return data;
    } catch (err) {
      console.error('Error updating pet stats:', err);
      setError('Failed to update pet');
      return null;
    }
  };

  // Care actions
  const feedPet = async () => {
    if (!userPet) return;
    const newHunger = Math.min(100, userPet.hunger + 20);
    await updatePetStats(userPet.id, { hunger: newHunger });
  };

  const cleanPet = async () => {
    if (!userPet) return;
    const newCleanliness = Math.min(100, userPet.love + 15); // Using love field as cleanliness
    await updatePetStats(userPet.id, { love: newCleanliness });
  };

  const giveMedicine = async () => {
    if (!userPet) return;
    const newHealth = Math.min(100, userPet.health + 10);
    await updatePetStats(userPet.id, { health: newHealth });
  };

  // Set up real-time subscriptions
  useEffect(() => {
    let subscription: any = null;

    const setupRealtimeSubscription = () => {
      console.log('Setting up realtime subscription...');
      subscription = supabase
        .channel('pets_changes')
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'pets',
        }, (payload) => {
          console.log('Realtime update received:', payload);
          fetchAllPets();
          if (ownerWallet) {
            fetchUserPet(ownerWallet);
          }
        })
        .subscribe();
    };

    setupRealtimeSubscription();

    return () => {
      if (subscription) {
        supabase.removeChannel(subscription);
      }
    };
  }, [ownerWallet]);

  // Initial fetch
  useEffect(() => {
    const initialize = async () => {
      setLoading(true);
      await fetchAllPets();
      
      if (ownerWallet) {
        await fetchUserPet(ownerWallet);
      }
      
      setLoading(false);
    };

    initialize();
  }, [ownerWallet]);

  // Check if user needs a new pet
  useEffect(() => {
    // Don't auto-create pets anymore - let the user choose name first
  }, []);

  return {
    pets,
    userPet,
    loading,
    error,
    feedPet,
    cleanPet,
    giveMedicine,
    createPet,
    createPetWithName,
    refetch: () => {
      fetchAllPets();
      if (ownerWallet) fetchUserPet(ownerWallet);
    },
  };
};