import { useEffect } from 'react';
import { supabase } from '../lib/supabase';

export const useGameLogic = () => {
  useEffect(() => {
    // Set up interval to decay pet stats every minute
    const interval = setInterval(async () => {
      try {
        // Get all alive pets
        const { data: pets, error } = await supabase
          .from('pets')
          .select('*')
          .eq('is_dead', false);

        if (error) throw error;

        // Update each pet's stats
        for (const pet of pets || []) {
          const newHunger = Math.max(0, pet.hunger - 3);
          const newLove = Math.max(0, pet.love - 2);
          const newHealth = Math.max(0, pet.health - 1);
          const isDead = newHunger === 0;

          await supabase
            .from('pets')
            .update({
              hunger: newHunger,
              love: newLove,
              health: newHealth,
              is_dead: isDead,
            })
            .eq('id', pet.id);
        }
      } catch (error) {
        console.error('Error in game logic:', error);
      }
    }, 60000); // 60 seconds

    return () => clearInterval(interval);
  }, []);
};