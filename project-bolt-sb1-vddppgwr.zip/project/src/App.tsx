import React, { useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletContextProvider } from './lib/wallet';
import BackgroundMusic from './components/BackgroundMusic';
import { PetMap } from './components/PetMap';
import { GameOverlay } from './components/GameOverlay';
import { PetControls } from './components/PetControls';
import { PetStatsComponent } from './components/PetStats';
import { usePets } from './hooks/usePets';
import type { Pet } from './types/pet';

// Available character types for random assignment
const CHARACTER_TYPES = ['awa', 'mame', 'popu', 'wawa', 'yoru', 'kuchi', 'tsuyo', 'special'];

// Generate random mob pets
function generateMobPets(count: number): Pet[] {
  const mobs: Pet[] = [];
  const names = [
    'Wild Pumpっち', 'Forest Pumpっち', 'Ocean Pumpっち', 'Sky Pumpっち',
    'Desert Pumpっち', 'Snow Pumpっち', 'Fire Pumpっち', 'Shadow Pumpっち',
    'Crystal Pumpっち', 'Golden Pumpっち', 'Silver Pumpっち', 'Rainbow Pumpっち'
  ];

  for (let i = 0; i < count; i++) {
    const randomName = names[Math.floor(Math.random() * names.length)];
    const randomCharacter = CHARACTER_TYPES[Math.floor(Math.random() * CHARACTER_TYPES.length)];
    
    mobs.push({
      id: `mob_${i}`,
      owner_id: "npc",
      name: randomName,
      character_type: randomCharacter, // Add character type for GIF selection
      x: Math.random() * 0.8 + 0.1, // 10-90% of field
      y: Math.random() * 0.8 + 0.1,
      target_x: Math.random() * 0.8 + 0.1,
      target_y: Math.random() * 0.8 + 0.1,
      hunger: Math.floor(Math.random() * 40) + 60, // 60-100
      love: Math.floor(Math.random() * 40) + 60,
      health: Math.floor(Math.random() * 30) + 70, // 70-100
      sleep: Math.floor(Math.random() * 50) + 50,
      poop: Math.floor(Math.random() * 20),
      stage: "adult",
      is_dead: false,
      created_at: new Date().toISOString(),
      last_updated: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      next_move_at: new Date().toISOString(),
    });
  }

  return mobs;
}
function GameContent() {
  const { connected, publicKey } = useWallet();
  const [overlayVisible, setOverlayVisible] = useState(true);
  const [myCharacter, setMyCharacter] = useState<string | null>(null);
  const [myPetName, setMyPetName] = useState<string | null>(null);

  const walletAddress = publicKey?.toString();
  const { pets: allPets, userPet, feedPet, playWithPet, giveMedicine, cleanPet, loading, createPetWithName } = usePets(walletAddress);

  // Generate random mob pets (8-12 mobs for lively world)
  const [mobPets] = useState<Pet[]>(() => generateMobPets(10));

  // 全てのペット（モブ + リアル）を結合
  const allDisplayPets = [...mobPets, ...allPets];

  const handleJoin = async (selectedCharacter: string, petName: string) => {
    setMyCharacter(selectedCharacter);
    setMyPetName(petName);
    setOverlayVisible(false);
    
    // Create pet with custom name if wallet is connected
    if (walletAddress && createPetWithName) {
      await createPetWithName(walletAddress, petName);
    }
  };

  return (
    <div className="game-container">
      {/* Background Music */}
      <BackgroundMusic />
      
      {/* 背景のワールド（常に表示） */}
      <div className="world-canvas">
        <PetMap 
          pets={allDisplayPets} 
          userPetId={userPet?.id} 
          selectedCharacter={myCharacter}
          userPetName={myPetName}
        />
      </div>

      {/* オーバーレイ（最初だけ表示） */}
      {overlayVisible && (
        <GameOverlay 
          onJoin={handleJoin}
          onJoinWithName={handleJoin}
          walletConnected={connected}
        />
      )}

      {/* 簡単な情報表示 */}
      {!overlayVisible && userPet && (
        <div className="stats-panel">
          <PetStatsComponent stats={{
            hunger: userPet.hunger,
            cleanliness: userPet.love, // Using love field as cleanliness for now
            health: userPet.health
          }} userPetName={myPetName} />
        </div>
      )}

      {/* お世話ボタン */}
      {!overlayVisible && userPet && (
        <div className="controls-panel">
          <PetControls
            onFeed={feedPet}
            onClean={cleanPet}
            onHeal={giveMedicine}
            disabled={loading || userPet.is_dead}
          />
        </div>
      )}
    </div>
  );
}

function App() {
  return (
    <WalletContextProvider>
      <GameContent />
    </WalletContextProvider>
  );
}

export default App;