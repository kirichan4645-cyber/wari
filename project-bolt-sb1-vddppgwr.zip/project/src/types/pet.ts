export interface Pet {
  id: string;
  owner_id: string;
  name: string;
  character_type?: string; // For GIF selection
  hunger: number;
  love: number;
  health: number;
  x: number;
  y: number;
  target_x: number;
  target_y: number;
  is_dead: boolean;
  created_at: string;
  last_updated: string;
  stage: string;
  sleep: number;
  poop: number;
  updated_at: string;
  next_move_at: string;
}

export interface PetStats {
  hunger: number;
  cleanliness: number;
  health: number;
}

export interface PetPosition {
  x: number;
  y: number;
}