import React from 'react';

interface PetControlsProps {
  onFeed: () => void;
  onClean: () => void;
  onHeal: () => void;
  disabled?: boolean;
}

export const PetControls: React.FC<PetControlsProps> = ({
  onFeed,
  onClean,
  onHeal,
  disabled = false,
}) => {
  return (
    <div className="flex gap-4">
        <button
          onClick={onFeed}
          disabled={disabled}
          className="control-btn feed-btn flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed w-16 h-16 p-2"
        >
          <img src="/lunch.png" alt="Feed" className="w-full h-full object-contain" />
        </button>

        <button
          onClick={onClean}
          disabled={disabled}
          className="control-btn play-btn flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed w-16 h-16 p-2"
        >
          <img src="/toilet.png" alt="Clean" className="w-full h-full object-contain" />
        </button>

        <button
          onClick={onHeal}
          disabled={disabled}
          className="control-btn heal-btn flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed w-16 h-16 p-2"
        >
          <img src="/health.png" alt="Health" className="w-full h-full object-contain" />
        </button>
    </div>
  );
};