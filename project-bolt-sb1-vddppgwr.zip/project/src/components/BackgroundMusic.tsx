import { useEffect, useRef } from "react";

export default function BackgroundMusic() {
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const startAudio = () => {
      audio.volume = 0.5; // Volume 50%
      audio.loop = true;  // Infinite loop
      audio.play().catch((err) => {
        console.log("Autoplay blocked:", err);
      });
      window.removeEventListener("click", startAudio);
    };

    // Play on first click or tap
    window.addEventListener("click", startAudio);

    return () => {
      window.removeEventListener("click", startAudio);
    };
  }, []);

  return (
    <audio
      ref={audioRef}
      src="https://github.com/kirichan4645-cyber/wari/raw/refs/heads/main/bgm1.mp3"
    />
  );
}