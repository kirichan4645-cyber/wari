import React, { useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Wallet, Play } from 'lucide-react';

interface GameOverlayProps {
  onJoin: (selectedCharacter: string) => void;
  onJoinWithName: (selectedCharacter: string, petName: string) => void;
  walletConnected: boolean;
}

const characters = [
  { id: 'awa', name: 'Awa', gif: '/awa.gif' },
  { id: 'mame', name: 'Mame', gif: '/mame.gif' },
  { id: 'popu', name: 'Popu', gif: '/popu.gif' },
  { id: 'wawa', name: 'Wawa', gif: '/wawa.gif' },
  { id: 'yoru', name: 'Yoru', gif: '/yoru.gif' },
  { id: 'kuchi', name: 'Kuchi', gif: '/kuchi.gif' },
  { id: 'tsuyo', name: 'Tsuyo', gif: '/tsuyo.gif' },
  { id: 'special', name: 'Special', gif: '/awa.gif' }, // 8体目
];

export const GameOverlay: React.FC<GameOverlayProps> = ({ onJoin, walletConnected }) => {
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);
  const [petName, setPetName] = useState<string>('');

  const handleJoinGame = () => {
    if (selectedCharacter && walletConnected && petName.trim()) {
      onJoin(selectedCharacter);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl p-8 max-w-2xl w-full mx-4 shadow-2xl">
        <div className="text-center mb-6">
          <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl mx-auto flex items-center justify-center mb-4">
            <span className="text-3xl">🎮</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Join pumpっち World</h1>
          <p className="text-gray-600">Connect your wallet and choose your character</p>
        </div>

        {/* Wallet Connection */}
        <div className="mb-6 text-center">
          {!walletConnected ? (
            <div>
              <p className="text-gray-700 mb-4">First, connect your Solana wallet:</p>
              <WalletMultiButton className="!bg-gradient-to-r !from-orange-500 !to-red-500 !hover:from-orange-600 !hover:to-red-600 !border-0 !rounded-xl !font-semibold !px-8 !py-3 !text-white !transition-all !duration-200 !transform !hover:scale-105" />
            </div>
          ) : (
            <div className="flex items-center justify-center gap-2 text-green-600 font-semibold">
              <Wallet size={20} />
              <span>Wallet Connected!</span>
            </div>
          )}
        </div>

        {/* Character Selection */}
        {walletConnected && (
          <div className="mb-6">
            {/* Pet Name Input */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-3 text-center">
                Choose your pet's name:
              </h3>
              <div className="max-w-xs mx-auto">
                <input
                  type="text"
                  value={petName}
                  onChange={(e) => setPetName(e.target.value)}
                  placeholder="e.g. My Pumpっち"
                  maxLength={12}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-center font-medium text-gray-800 focus:border-orange-500 focus:outline-none transition-colors"
                />
                <p className="text-xs text-gray-500 mt-2 text-center">
                  Please enter within 12 characters
                </p>
              </div>
            </div>

            <h3 className="text-lg font-semibold text-gray-800 mb-4 text-center">
              Choose Your Pumpっち:
            </h3>
            <div className="grid grid-cols-4 gap-4">
              {characters.map((char) => (
                <div
                  key={char.id}
                  onClick={() => setSelectedCharacter(char.id)}
                  className={`
                    relative cursor-pointer rounded-xl p-3 transition-all duration-200 transform hover:scale-105
                    ${selectedCharacter === char.id 
                      ? 'bg-orange-100 border-2 border-orange-500 shadow-lg' 
                      : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
                    }
                  `}
                >
                  <div className="aspect-square bg-white rounded-lg mb-2 flex items-center justify-center overflow-hidden">
                    <img 
                      src={char.gif} 
                      alt={char.name}
                      className="w-12 h-12 object-contain"
                      onError={(e) => {
                        // Fallback to emoji if GIF fails to load
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        target.parentElement!.innerHTML = '<span class="text-2xl">🎃</span>';
                      }}
                    />
                  </div>
                  <p className="text-xs font-medium text-center text-gray-700">
                    {char.name}
                  </p>
                  {selectedCharacter === char.id && (
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Join Button */}
        {walletConnected && (
          <div className="text-center">
            <button
              onClick={handleJoinGame}
              disabled={!selectedCharacter || !petName.trim()}
              className={`
                flex items-center justify-center gap-2 mx-auto px-8 py-3 rounded-xl font-semibold text-white transition-all duration-200 transform
                ${selectedCharacter && petName.trim()
                  ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 hover:scale-105 shadow-lg' 
                  : 'bg-gray-400 cursor-not-allowed'
                }
              `}
            >
              <Play size={20} />
              <span>Join Game</span>
            </button>
            {(!selectedCharacter || !petName.trim()) && (
              <p className="text-sm text-gray-500 mt-2">
                {!petName.trim() ? 'Please enter your pet\'s name' : 'Please select a character'}
              </p>
            )}
          </div>
        )}

        {/* Instructions */}
        <div className="mt-6 bg-orange-50 border border-orange-200 rounded-lg p-4">
          <p className="text-sm text-orange-800 text-center">
            <strong>How to play:</strong> Choose your favorite Pumpっち and join the world! 
            Your character will spawn randomly on the map and you can see other players' pets moving around.
          </p>
        </div>
      </div>
    </div>
  );
};