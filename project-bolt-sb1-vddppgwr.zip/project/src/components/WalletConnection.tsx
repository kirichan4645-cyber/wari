import React from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Wallet } from 'lucide-react';

interface WalletConnectionProps {
  isVisible: boolean;
}

export const WalletConnection: React.FC<WalletConnectionProps> = ({ isVisible }) => {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl">
        <div className="text-center">
          <div className="mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl mx-auto flex items-center justify-center mb-4">
              <span className="text-3xl">🐣</span>
            </div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">pumpっち</h1>
            <p className="text-gray-600">Your Web3 Virtual Pet</p>
          </div>
          
          <div className="mb-6">
            <p className="text-gray-700 mb-4">
              Connect your Solana wallet to start raising your very own pumpっち! 
              Feed, play, and care for your digital pet in this decentralized world.
            </p>
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
              <p className="text-sm text-orange-800">
                <strong>Remember:</strong> If your pet's hunger reaches 0, it will die and you'll need to create a new one!
              </p>
            </div>
          </div>

          <div className="flex flex-col items-center gap-4">
            <WalletMultiButton className="!bg-gradient-to-r !from-orange-500 !to-red-500 !hover:from-orange-600 !hover:to-red-600 !border-0 !rounded-xl !font-semibold !px-8 !py-3 !text-white !transition-all !duration-200 !transform !hover:scale-105" />
            
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Wallet size={16} />
              <span>Phantom, Solflare, and more supported</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};