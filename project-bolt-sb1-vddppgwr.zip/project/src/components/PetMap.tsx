import React, { useEffect, useRef } from 'react';
import { updatePetMovement, pickTarget, type PetLike } from '../lib/movement';
import type { Pet } from '../types/pet';

interface PetMapProps {
  pets: Pet[];
  userPetId?: string;
  selectedCharacter?: string | null;
  userPetName?: string | null;
}

// Fixed field dimensions for coordinate system
const FIELD_WIDTH = 1920;
const FIELD_HEIGHT = 1100; // Slightly taller to eliminate vertical margins

export const PetMap: React.FC<PetMapProps> = ({ pets, userPetId, selectedCharacter, userPetName }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const backgroundImageRef = useRef<HTMLImageElement | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const cameraRef = useRef({ x: 0, y: 0 });
  const zoomRef = useRef(1.0); // ズーム倍率（1.0 = 100%）
  const dragRef = useRef({ isDragging: false, lastX: 0, lastY: 0 });
  const scaleRef = useRef(1.0);
  const animationFrameRef = useRef<number>();
  const movingPetsRef = useRef<PetLike[]>([]);

  // Fixed field dimensions for coordinate system
  const FIELD_WIDTH = 1920;
  const FIELD_HEIGHT = 1100;

  // Load background image
  useEffect(() => {
    const img = new Image();
    img.onload = () => {
      backgroundImageRef.current = img;
    };
    img.src = '/carpet.png';
  }, []);

  // Initialize moving pets when pets change
  useEffect(() => {
    // Only update if pets array actually changed, preserve existing movement state
    const newMovingPets = pets.map(pet => {
      const existing = movingPetsRef.current.find(p => p.id === pet.id);
      if (existing) {
        // Keep existing movement state but update targets if they changed
        return {
          ...existing,
          target_x: pet.target_x,
          target_y: pet.target_y,
        };
      } else {
        // New pet - initialize with current position
        return {
          id: pet.id,
          x: pet.x,
          y: pet.y,
          target_x: pet.target_x,
          target_y: pet.target_y,
          next_move_at: pet.next_move_at,
          // Initialize with slight delay to avoid immediate movement
          waitUntil: Date.now() + 500, // Start moving after 0.5 seconds
        };
      }
    });
    movingPetsRef.current = newMovingPets;
  }, [pets]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    function resizeCanvas() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    

    function getFitScale() {
      // Always fill the entire screen, may crop field if aspect ratios don't match
      return Math.max(
        canvas.width / FIELD_WIDTH,
        canvas.height / FIELD_HEIGHT
      );
    }

    function getCurrentScale() {
      return getFitScale() * zoomRef.current;
    }
    function limitCamera() {
      const scale = getCurrentScale();
      const visibleWidth = canvas.width / scale;
      const visibleHeight = canvas.height / scale;
      
      // カメラ位置の制限範囲を計算
      const minX = Math.min(0, (visibleWidth - FIELD_WIDTH) / 2);
      const maxX = Math.max(0, (FIELD_WIDTH - visibleWidth) / 2);
      const minY = Math.min(0, (visibleHeight - FIELD_HEIGHT) / 2);
      const maxY = Math.max(0, (FIELD_HEIGHT - visibleHeight) / 2);
      
      cameraRef.current.x = Math.max(minX, Math.min(maxX, cameraRef.current.x));
      cameraRef.current.y = Math.max(minY, Math.min(maxY, cameraRef.current.y));
    }

    // Mouse event handlers
    function handleMouseDown(e: MouseEvent) {
      dragRef.current.isDragging = true;
      dragRef.current.lastX = e.clientX;
      dragRef.current.lastY = e.clientY;
      canvas.style.cursor = 'grabbing';
    }

    function handleMouseMove(e: MouseEvent) {
      if (!dragRef.current.isDragging) return;
      
      const scale = getCurrentScale();
      const deltaX = (e.clientX - dragRef.current.lastX) / scale;
      const deltaY = (e.clientY - dragRef.current.lastY) / scale;
      
      cameraRef.current.x -= deltaX;
      cameraRef.current.y -= deltaY;
      
      limitCamera();
      
      dragRef.current.lastX = e.clientX;
      dragRef.current.lastY = e.clientY;
    }

    function handleMouseUp() {
      dragRef.current.isDragging = false;
      canvas.style.cursor = 'grab';
    }

    // Touch event handlers
    function handleTouchStart(e: TouchEvent) {
      e.preventDefault();
      const touch = e.touches[0];
      dragRef.current.isDragging = true;
      dragRef.current.lastX = touch.clientX;
      dragRef.current.lastY = touch.clientY;
    }

    function handleTouchMove(e: TouchEvent) {
      e.preventDefault();
      if (!dragRef.current.isDragging) return;
      
      const touch = e.touches[0];
      const scale = getCurrentScale();
      const deltaX = (touch.clientX - dragRef.current.lastX) / scale;
      const deltaY = (touch.clientY - dragRef.current.lastY) / scale;
      
      cameraRef.current.x -= deltaX;
      cameraRef.current.y -= deltaY;
      
      limitCamera();
      
      dragRef.current.lastX = touch.clientX;
      dragRef.current.lastY = touch.clientY;
    }

    function handleTouchEnd(e: TouchEvent) {
      e.preventDefault();
      dragRef.current.isDragging = false;
    }
    function draw() {
      const scale = getCurrentScale();

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Update pet positions every frame
      movingPetsRef.current.forEach(movingPet => {
        updatePetMovement(movingPet, FIELD_WIDTH, FIELD_HEIGHT);
      });
      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.scale(scale, scale);
      ctx.translate(-FIELD_WIDTH / 2 - cameraRef.current.x, -FIELD_HEIGHT / 2 - cameraRef.current.y);

      // Draw field background
      if (backgroundImageRef.current) {
        const img = backgroundImageRef.current;
        const pattern = ctx.createPattern(img, 'repeat');
        if (pattern) {
          ctx.fillStyle = pattern;
          ctx.fillRect(0, 0, FIELD_WIDTH, FIELD_HEIGHT);
        }
      } else {
        // Fallback gradient background
        const gradient = ctx.createLinearGradient(0, 0, FIELD_WIDTH, FIELD_HEIGHT);
        gradient.addColorStop(0, '#fce9f2');
        gradient.addColorStop(0.5, '#f3e5f5');
        gradient.addColorStop(1, '#e8f5e8');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, FIELD_WIDTH, FIELD_HEIGHT);
      }

      // Draw field border
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
      ctx.lineWidth = 2;
      ctx.strokeRect(0, 0, FIELD_WIDTH, FIELD_HEIGHT);

      // Draw pets
      movingPetsRef.current.forEach((pet) => {
        const originalPet = pets.find(p => p.id === pet.id);
        if (!originalPet || originalPet.is_dead) return;

        const isUserPet = pet.id === userPetId;
        const isMobPet = originalPet.owner_id === 'npc';
        const petSize = 128;
        
        // Convert normalized coordinates to field coordinates
        const x = pet.x * FIELD_WIDTH;
        const y = pet.y * FIELD_HEIGHT;

        // All pets are now drawn as DOM elements with GIFs
        // No canvas drawing needed for pets
      });

      ctx.restore();

      // Continue animation loop
      animationFrameRef.current = requestAnimationFrame(draw);
    }

    // Update DOM character position
    function updateDOMCharacter() {
      if (!containerRef.current || !selectedCharacter) return;
      
      const userPet = movingPetsRef.current.find(pet => pet.id === userPetId);
      if (!userPet) return;

      const canvas = canvasRef.current;
      if (!canvas) return;

      const scale = getCurrentScale();
      
      // Convert pet coordinates to screen coordinates
      const fieldX = userPet.x * FIELD_WIDTH;
      const fieldY = userPet.y * FIELD_HEIGHT;
      
      // Apply camera and scale transformations
      const screenX = (fieldX - FIELD_WIDTH/2 - cameraRef.current.x) * scale + canvas.width/2;
      const screenY = (fieldY - FIELD_HEIGHT/2 - cameraRef.current.y) * scale + canvas.height/2;
      
      // Update character element position
      const charElement = containerRef.current.querySelector('.user-character') as HTMLElement;
      if (charElement) {
        const charSize = 128; // Same size as all pets
        charElement.style.left = `${screenX - charSize/2}px`;
        charElement.style.top = `${screenY - charSize/2}px`;
        charElement.style.width = `${charSize}px`;
        charElement.style.height = `${charSize}px`;
      }
    }

    // Update DOM mob characters
    function updateDOMMobCharacters() {
      if (!containerRef.current) return;

      const canvas = canvasRef.current;
      if (!canvas) return;

      const scale = getCurrentScale();
      
      // Update all mob characters
      movingPetsRef.current.forEach((pet) => {
        const originalPet = pets.find(p => p.id === pet.id);
        if (!originalPet || originalPet.is_dead || originalPet.owner_id !== 'npc' || !originalPet.character_type) return;

        // Convert pet coordinates to screen coordinates
        const fieldX = pet.x * FIELD_WIDTH;
        const fieldY = pet.y * FIELD_HEIGHT;
        
        // Apply camera and scale transformations
        const screenX = (fieldX - FIELD_WIDTH/2 - cameraRef.current.x) * scale + canvas.width/2;
        const screenY = (fieldY - FIELD_HEIGHT/2 - cameraRef.current.y) * scale + canvas.height/2;
        
        // Update mob character element position
        const mobElement = containerRef.current.querySelector(`.mob-character-${pet.id}`) as HTMLElement;
        if (mobElement) {
          const mobSize = 128; // Same size as all pets
          mobElement.style.left = `${screenX - mobSize/2}px`;
          mobElement.style.top = `${screenY - mobSize/2}px`;
          mobElement.style.width = `${mobSize}px`;
          mobElement.style.height = `${mobSize}px`;
        }
      });
    }
    // Initialize canvas and start animation
    resizeCanvas();
    canvas.style.cursor = 'grab';
    
    function animate() {
      draw();
      updateDOMCharacter();
      updateDOMMobCharacters();
      animationFrameRef.current = requestAnimationFrame(animate);
    }
    animate();

    // Handle window resize
    window.addEventListener('resize', resizeCanvas);
    
    // Add event listeners
    canvas.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    
    canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
    canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
    canvas.addEventListener('touchend', handleTouchEnd, { passive: false });

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      canvas.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEnd);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [pets, userPetId, selectedCharacter]);

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const fitScale = Math.max(
      canvas.width / FIELD_WIDTH,
      canvas.height / FIELD_HEIGHT
    );

    if (e.deltaY < 0) {
      zoomRef.current *= 1.1; // 拡大
    } else {
      zoomRef.current /= 1.1; // 縮小
    }

    // フィットスケール以下にはならないようにする
    zoomRef.current = Math.max(fitScale, Math.min(3, zoomRef.current));
  };

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden">
      <canvas
        ref={canvasRef}
        onWheel={handleWheel}
        className="block"
        style={{ 
          imageRendering: 'pixelated',
          width: '100vw',
          height: '100vh'
        }}
      />
      
      {/* User character as DOM element for GIF animation */}
      {selectedCharacter && (
        <div className="user-character absolute pointer-events-none z-10" style={{ transform: 'translate(-50%, -50%)' }}>
          <img
            src={`/${selectedCharacter}.gif`}
            alt="User Character"
            style={{ 
              imageRendering: 'pixelated',
              width: '128px',
              height: '128px',
              display: 'block',
            }}
          />
          {userPetName && (
            <div 
              className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-blue-500/90 backdrop-blur-sm rounded-lg px-3 py-1 text-sm font-bold text-white shadow-lg border border-blue-300/30 whitespace-nowrap"
              style={{ minWidth: 'max-content' }}
            >
              <div className="text-center">
                <div className="text-xs text-blue-200">You</div>
                <div>{userPetName}</div>
              </div>
            </div>
          )}
        </div>
      )}
      
      {/* Mob characters as DOM elements for GIF animation */}
      {pets.filter(pet => pet.owner_id === 'npc' && pet.character_type && !pet.is_dead).map(pet => (
        <div
          key={pet.id}
          className={`mob-character-${pet.id} absolute pointer-events-none z-5`}
          style={{ 
            transform: 'translate(-50%, -50%)',
          }}
        >
          <img
            src={`/${pet.character_type}.gif`}
            alt={`Mob ${pet.name}`}
            style={{ 
              imageRendering: 'pixelated',
              opacity: 1.0,
              width: '128px',
              height: '128px',
            }}
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
            }}
          />
          <div 
            className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-transparent rounded-lg px-2 py-1 text-xs font-medium text-gray-700 whitespace-nowrap"
            style={{ minWidth: 'max-content' }}
          >
            <div className="text-center">
              <div className="text-xs text-gray-500">NPC</div>
              <div>{pet.name}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};