import React from 'react';
import { Droplets, Zap, Apple } from 'lucide-react';
import type { PetStats } from '../types/pet';

interface PetStatsProps {
  stats: PetStats;
  userPetName?: string | null;
}

export const PetStatsComponent: React.FC<PetStatsProps> = ({ stats, userPetName }) => {
  return (
    <div className="p-2 sm:p-3 md:p-4">
      <div className="pet-name mb-2 sm:mb-3">
        <span className="name-icon">🎮</span>
        <span className="text-sm sm:text-base md:text-lg font-semibold text-black">{userPetName || 'My Pumpっち'}</span>
      </div>
      
      <div className="space-y-2 sm:space-y-3">
        {/* Fullness */}
        <div className="flex items-center gap-2 sm:gap-3">
          <Apple className="text-green-500" size={16} />
          <div className="flex-1">
            <div className="flex justify-between text-xs sm:text-sm mb-1">
              <span className="text-black font-medium">Fullness</span>
              <span className="text-black">{stats.hunger}/100</span>
            </div>
            <div className="w-full bg-gray-300 rounded-full h-1.5 sm:h-2">
              <div
                className="h-1.5 sm:h-2 rounded-full transition-all duration-300 bg-gradient-to-r from-green-500 to-green-600"
                style={{ width: `${stats.hunger}%` }}
              />
            </div>
          </div>
        </div>

        {/* Cleanliness */}
        <div className="flex items-center gap-2 sm:gap-3">
          <Droplets className="text-pink-500" size={16} />
          <div className="flex-1">
            <div className="flex justify-between text-xs sm:text-sm mb-1">
              <span className="text-black font-medium">Cleanliness</span>
              <span className="text-black">{stats.cleanliness}/100</span>
            </div>
            <div className="w-full bg-gray-300 rounded-full h-1.5 sm:h-2">
              <div
                className="h-1.5 sm:h-2 rounded-full transition-all duration-300 bg-gradient-to-r from-pink-500 to-pink-600"
                style={{ width: `${stats.cleanliness}%` }}
              />
            </div>
          </div>
        </div>

        {/* Health */}
        <div className="flex items-center gap-2 sm:gap-3">
          <Zap className="text-blue-500" size={16} />
          <div className="flex-1">
            <div className="flex justify-between text-xs sm:text-sm mb-1">
              <span className="text-black font-medium">Health</span>
              <span className="text-black">{stats.health}/100</span>
            </div>
            <div className="w-full bg-gray-300 rounded-full h-1.5 sm:h-2">
              <div
                className="h-1.5 sm:h-2 rounded-full transition-all duration-300 bg-gradient-to-r from-blue-500 to-blue-600"
                style={{ width: `${stats.health}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};