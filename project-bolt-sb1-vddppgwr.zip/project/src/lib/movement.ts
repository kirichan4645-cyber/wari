// --- Movement Parameters ---
const SPEED_PX_PER_FRAME = 0.0015;     // Speed: ultra ultra slow for extremely peaceful movement
const MIN_STEP_PX         = 50;         // Minimum distance per movement
const MAX_STEP_PX         = 150;        // Maximum distance per movement (local)
const WAIT_MIN_MS         = 2000;       // Minimum wait time (2 seconds)
const WAIT_MAX_MS         = 8000;       // Maximum wait time (8 seconds)
const LONG_RANGE_CHANCE   = 0.2;        // 20% chance for long-range movement

export type PetLike = {
  id: string;
  x: number;
  y: number;
  target_x?: number | null;
  target_y?: number | null;
  next_move_at?: string | null;
  // Client-side only temporary properties (not saved to DB)
  waitUntil?: number;
};

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
const distance = (ax: number, ay: number, bx: number, by: number) => {
  const dx = ax - bx, dy = ay - by;
  return Math.hypot(dx, dy);
};

// Pick new target using pixel coordinates for natural movement
export function pickTarget(pet: PetLike, fieldWidth: number, fieldHeight: number) {
  let newX, newY, d;

  const margin = 50; // 50px margin from edges

  // Convert normalized coordinates to pixel coordinates for calculation
  const currentPixelX = pet.x * fieldWidth;
  const currentPixelY = pet.y * fieldHeight;

  // 20% chance for long-range movement (full map)
  if (Math.random() < LONG_RANGE_CHANCE) {
    // Complete random movement across entire map
    newX = Math.random() * (fieldWidth - 2 * margin) + margin;
    newY = Math.random() * (fieldHeight - 2 * margin) + margin;
  } else {
    // 80% chance for local wandering around current position
    do {
      const dx = (Math.random() - 0.5) * 2 * MAX_STEP_PX;
      const dy = (Math.random() - 0.5) * 2 * MAX_STEP_PX;
      newX = clamp(currentPixelX + dx, margin, fieldWidth - margin);
      newY = clamp(currentPixelY + dy, margin, fieldHeight - margin);
      d = distance(newX, newY, currentPixelX, currentPixelY);
    } while (d < MIN_STEP_PX); // Ensure minimum distance
  }

  // Convert back to normalized coordinates for storage
  pet.target_x = newX / fieldWidth;
  pet.target_y = newY / fieldHeight;
  
  // Random wait time: 1-5 seconds after reaching target
  const wait = WAIT_MIN_MS + Math.random() * (WAIT_MAX_MS - WAIT_MIN_MS);
  pet.waitUntil = Date.now() + wait;
}

export function updatePetMovement(pet: PetLike, fieldWidth: number, fieldHeight: number) {
  const now = Date.now();

  // Check if pet is in waiting period (client-side only)
  if (pet.waitUntil && now < pet.waitUntil) {
    return pet;
  }

  // No target or reached target → pick new target
  if (
    pet.target_x == null || pet.target_y == null ||
    distance(pet.x * fieldWidth, pet.y * fieldHeight, pet.target_x * fieldWidth, pet.target_y * fieldHeight) < 5
  ) {
    pickTarget(pet, fieldWidth, fieldHeight);
    // Don't return here - let it start moving towards the new target
  }

  // Move towards target at constant speed (in pixel space)
  const currentPixelX = pet.x * fieldWidth;
  const currentPixelY = pet.y * fieldHeight;
  const targetPixelX = pet.target_x * fieldWidth;
  const targetPixelY = pet.target_y * fieldHeight;
  
  const dx = targetPixelX - currentPixelX;
  const dy = targetPixelY - currentPixelY;
  const dist = Math.sqrt(dx * dx + dy * dy);

  if (dist > 1) { // Only move if there's meaningful distance
    const moveX = (dx / dist) * SPEED_PX_PER_FRAME;
    const moveY = (dy / dist) * SPEED_PX_PER_FRAME;
    
    // Update normalized coordinates
    pet.x = clamp((currentPixelX + moveX) / fieldWidth, 0.05, 0.95);
    pet.y = clamp((currentPixelY + moveY) / fieldHeight, 0.05, 0.95);
  }

  return pet;
}